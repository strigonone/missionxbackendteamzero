// NODE server listening port
const port = Number(process.env.PORT || 4000);

module.exports = { port };
